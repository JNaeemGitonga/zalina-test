import React from 'react';
import './maincomponent.css';

export default class Box extends React.Component {
    
    render() {

        return (
            <div id='box-under-header'>
                <h3 className='header-info'>| <em>Gabrielle Zalina presents Texture Masters</em> |</h3>
            </div>
        )
    }
}