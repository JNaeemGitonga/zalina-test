import React from 'react';

export default class Events extends React.Component {
    render () {
        return (
            <div id='events-box'>
                <h1 className='event-message'> Events Coming Soon!</h1>
            </div>
        )
    }
    

}