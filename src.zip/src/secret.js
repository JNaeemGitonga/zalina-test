export const clientId = 'd73391cc6d414b6a84a8b9958b9db690'
export const secret = '308921940.d73391c.4795a30aa57342e1a2f38028a53a53c2'

